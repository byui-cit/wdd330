import buildNavigation  from './router.js';

const navElement = document.getElementById('mainNav');
buildNavigation(navElement);